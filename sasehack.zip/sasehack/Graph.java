import java.io.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class Graph {
    private String title;
    private List<Node> nodes;
    private Map<Node, double[][]> coefficients;

    public static void main(String[] args) {
        Graph g = new Graph();
        g.readSteps("Menu.txt");
    }

    public Graph() {
        nodes = new ArrayList<>();
        coefficients = new HashMap<>();
    }

    public String getTitle() {
        return title;
    }

    public void readSteps(String fileName) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String titleLine = reader.readLine();
            title = titleLine.split("\t")[1];

            while (true) {
                String nameLine = reader.readLine();
                if (nameLine == null) {
                    break;
                }

                String textLine = reader.readLine();
                Node node = new Node(nameLine.split("\t")[1], textLine.split("\t")[1]);
                nodes.add(node);

                String featureLine = reader.readLine();
                node.addFeatures(featureLine.split("\t")[1].split(", "));

                String dataLine = reader.readLine();
                node.readData(dataLine.split("\t")[1]);

                String previousLine = reader.readLine();
                if (previousLine.split("\t").length == 2) {
                    String[] prevs = previousLine.split("\t")[1].split(", ");
                    for (String prev: prevs) {
                        node.addPrev(Node.get(prev));
                        Node.get(prev).addSucc(node);
                    }
                    coefficients.put(node, node.getCoefficients());
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
