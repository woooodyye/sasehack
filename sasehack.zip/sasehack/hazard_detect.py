import nltk

from rake_nltk  import Rake

from nltk.corpus import wordnet

r = Rake()

text = "I injured myself during labwork on thursday during the microfabrication process, I was operating on the electrospinning" \
       "machine and I accidentally injured my self."

r.extract_keywords_from_text(text)

L = r.get_ranked_phrases()



# pos_in_chart takes in two lists, L is the list of keywords from the injury memo in the dataset
# keywords is a list of words included in the chart. The function compares keywords in the report to identify the place
# in pipeline where it happened to help trace back the potential preconditions that triggered this injury.

def pos_in_chart(L,keywords):
    pos = []
    for i in range(1,len(L)):
        word = L[i];
        for j in range(1,len(keywords)):
            if word.lower() == keywords[j].lower() :
                pos.append(keywords.index(keywords[j]));

    pos.sort()

    return pos


def get_syn(word):
    synonyms = []
    for syn in wordnet.synsets(word):
        for l in syn.lemmas():

            synonyms.append(l.name())

    synonyms = list(dict.fromkeys(synonyms))
    return  synonyms





