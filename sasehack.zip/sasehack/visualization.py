import  graphviz
import sys
import io

from graphviz import Digraph


with open("Menu1.txt") as f:
    title = f.readline();
    lines = f.readlines();



results = []
for line in lines:
    results.append(  line.split(',') )



#num represents number of attributes, must be greater than 1
def create_dict(results,num):
    Dict = {}
    for i in range(0, len(results), num):
        word = ''.join(results[i])

        key = word[word.index('\t') + 1: len(word)]

        value = []
        D = {}
        if num< 2 : continue
        else:
            for j in range(1,num):
                fi = ''.join(results[j+i])

                f_name = fi[0 : fi.index(('\t'))]


                fi = fi[fi.index('\t') + 1: len(fi)]


                D[f_name] = fi;

                value.append(fi);

        Dict[key] = D;


    return Dict


Dict = create_dict(results,4)


dot = Digraph(comment= title)


for key,value in Dict.items():

    dot.node(key,''.join([value for key,value in value.items() if key !='Previous']))

    if value['Previous'] == '\n':
        continue
    else:
        vals = value['Previous'].split(' ')
        for v in vals:
            dot.edge(v,key, constraint = 'true')


dot.render('test2.gv', view = True)