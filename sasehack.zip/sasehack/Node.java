import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.io.*;
import org.ejml.simple.SimpleMatrix;

public class Node {
    private int id;
    private String name;
    private String text;
    private List<String> features;
    private List<List<Double>> data;
    private List<Node> prev;
    private List<Node> succ;
    static private Map<String, Node> map = new HashMap<>();

    public Node(String name, String text) {
        this.id = map.size();
        this.name = name;
        this.text = text;
        features = new ArrayList<>();
        data = new ArrayList<>();
        prev = new ArrayList<>();
        succ = new ArrayList<>();
        map.put(name, this);
    }

    public String getName() {
        return name;
    }

    public String getText() {
        return text;
    }

    public List<String> getFeatures() {
        return new ArrayList<>(features);
    }

    void addFeatures(String[] features) {
        for (int i = 0; i < features.length; i += 1) {
            this.features.add(features[i]);
        }
    }

    void addSucc(Node node) {
        succ.add(node);
    }

    void addPrev(Node node) {
        prev.add(node);
    }

    List<Node> getPrev() {
        return new ArrayList<>(prev);
    }

    List<Node> getSucc() {
        return new ArrayList<>(succ);
    }

    public static Node get(String name) {
        return map.get(name);
    }

    public void readData(String fileName) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                List<Double> list = new ArrayList<>();
                data.add(list);
                String[] vals = line.split(",");
                for (int i = 0; i < vals.length; i += 1) {
                    list.add(Double.parseDouble(vals[i]));
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public double[][] getCoefficients() {
        List<List<Double>> input = new ArrayList<>();
        for (int i = 0; i < data.size(); i += 1) {
            List<Double> entry = new ArrayList<>();
            input.add(entry);
            for (Node node: prev) {
                entry.addAll(node.data.get(i));
            }
        }
        SimpleMatrix in = new SimpleMatrix(input.size(), input.get(0).size());
        for (int i = 0; i < in.numRows(); i += 1) {
            for (int j = 0; j < in.numCols(); j += 1) {
                in.set(i, j, input.get(i).get(j));
            }
        }
        double[][] result = new double[features.size()][input.get(0).size()];
        for (int k = 0; k < features.size(); k += 1) {
            SimpleMatrix out = new SimpleMatrix(input.size(), 1);
            for (int i = 0; i < input.size(); i += 1) {
                out.set(i, 0, data.get(i).get(k));
            }
            SimpleMatrix coefficient = in.transpose().mult(in).mult(in.transpose().mult(out));
            System.out.println(coefficient);
            for (int j = 0; j < input.get(0).size(); j += 1) {
                result[k][j] = coefficient.get(j, 0);
            }
        }

        return result;
    }
}
